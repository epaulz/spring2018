# CPSC 3500

my_grades = {"hw":[100.0,85.0,100.0,93.0,90.0,150.0,90.0,100.0,75.0,96.0,58.0],
						"quizzes":[75.0,100.0,90.0,60.0,0.0,90.0,75.0,90.0,100.0],
						"midterm":[58.0],
						"final":[58.0]}

class_grades = {"hw":[94.8,66.6,93.4,86.0,133.9,83.8,82.6,75.2,79.3,77.1],
						  "quizzes":[59.6,80.2,78.8,55.7,75.0,62.4,55.0,62.4,68.4],
						  "midterm":[58.7],
						  "final":[60.0]} 
		  
def average(numbers):
	total = float(sum(numbers))
	total = total / len(numbers)
	return total
	
def get_average(x):
    hw = average(x["hw"])
    quizzes = average(x["quizzes"])
    midterm = average(x["midterm"])
    final = average(x["final"])
    return hw*.20 + quizzes*.10 + midterm*.30 + final*.40
	
def get_letter_grade(score):
	if score >= 90:
		return "A"
	elif score >= 80:
		return "B"
	elif score >= 70:
		return "C"
	elif score >= 60:
		return "D"
	else:
		return "F"

print "Current grade: %s (%s)" % (get_letter_grade(get_average(my_grades)), get_average(my_grades))
print "Class average: %s (%s)" % (get_letter_grade(get_average(class_grades)), get_average(class_grades))