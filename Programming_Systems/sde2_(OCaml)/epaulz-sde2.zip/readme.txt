Eric Paulz (epaulz)
CPSC 3520-001
SDE2 - OCaml

Contents of archive 'epaulz-sde2.zip':
1. readme.txt: this file
2. sde2.caml:  source code file for function implementations
3. sde2.log:    log of an OCaml session testing my functions


Pledge: On my honor I have neither given nor received aid on this exam.
