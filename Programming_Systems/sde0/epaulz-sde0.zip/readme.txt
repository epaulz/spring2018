I have read the CPSC/ECE 3520 Spring 2018 course syllabus.
