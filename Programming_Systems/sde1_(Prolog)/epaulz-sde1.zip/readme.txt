Eric Paulz (epaulz)
CPSC 3520-001
SDE1 - Prolog

Contents of 'epaulz-sde1.zip':
- readme.txt : this file
- sde1.pro : contains all predicates specified in the SDE1 documentation
- sde1.log : log of a Prolog session in which i tested each of the predicates

Pledge:
On my honor I have neither given nor received aid on this exam (project).
SIGN ___Eric Paulz___